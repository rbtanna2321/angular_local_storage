import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.scss']
})
export class SignupComponent implements OnInit {


  signUpDataObject = {
    id:101,
    firstName: null,
    lastName: null,
    email: null,
    mobileNumber: null,
    password:null,
    addressLine:null,
    city:null,
    state:null,
    country:null
  }

  userData :any =  [];

  constructor(private router: Router

  ) { }

  ngOnInit() {
    if(localStorage.getItem('userData')){
      this.userData.push(JSON.parse(localStorage.getItem('userData')));  
      console.log("****",this.userData)
    }
    
  }

  signUpFunction(){
    if(localStorage.getItem('userData')){
      let last= this.userData.slice(-1);

      console.log("====>",last)
      this.signUpDataObject.id = Number(last[0].id) + 1;
  
    }
      
    this.userData.push(this.signUpDataObject)
    localStorage.setItem('userData', JSON.stringify(this.userData));
      this.router.navigate(['/user'])
  }

}
