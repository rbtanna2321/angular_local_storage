import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.scss']
})
export class UserComponent implements OnInit {
  userData:any;
  constructor() { }

  ngOnInit() {
    this.userData = JSON.parse(localStorage.getItem('userData'));

    console.log("=============>", this.userData)
  }

}
