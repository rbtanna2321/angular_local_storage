import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  userData:any;
  loginDataObject = {
    mobileNumber: null,
    password: null
  }
  constructor() { }

  ngOnInit() {

    this.userData = JSON.parse(localStorage.getItem('userData'));

  }

  loginFunction(){
    let loginValidation= this.userData.map(data =>{
      if((data.mobileNumber === this.loginDataObject.mobileNumber) && (data.password === this.loginDataObject.password)){
        return true;
      }else{
        return false;
      }
    })
    if(loginValidation){
      alert('login Sucessfully');
          
    }else{
      alert('Bad Credential');
    }

  }

}
